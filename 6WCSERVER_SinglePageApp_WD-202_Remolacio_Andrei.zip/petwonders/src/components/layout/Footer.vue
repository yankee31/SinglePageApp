<template>
	<div class="footer">
		<p>© 2020 Copyright: PET WONDERS</p>
	</div>
</template>
<script>
	export default{
		name: "Footer"
	};
</script>
<style scoped>
	.footer{
		color: white;
		text-align: center;
		width: 100%;
		height: 60px;
		bottom:0;
		left:0;
		position:fixed;
		background-color: black;
	}
</style>