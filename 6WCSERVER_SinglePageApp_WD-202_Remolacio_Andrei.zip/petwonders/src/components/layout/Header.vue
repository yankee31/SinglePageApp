<template>
	<header class="header">
		<nav>
			<ul>
				<li id="logo">PW</li>
				<li style="padding-left:24%"><a  href="#home">Home</a></li>
				<li><a href="#about">About</a></li>
				<li><a href="">Services</a></li>
				<li><a href="">Contact Us</a></li>
			</ul>
		</nav>
	</header>
</template>
<script>
	export default{
		name:"Header"
	};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Monda:wght@700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');
	.header{
		color:#50A19C;
	}
	#logo{
	margin-left: 2%;
	font-family: Avenir;
		padding: 10px;
		width: 36px;
		color:white;
		border-radius: 50%;
		border-style: solid;
	font-size: 24px;
	font-family: 'Bebas Neue', cursive;
	}
	ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
	font-family: 'Monda', sans-serif;
	font-size: 24px;
  display: block;
  text-decoration: none;
  color: #50A19C;
  text-align: center;
  padding: 14px 16px;
}

li a:hover {
  color: white;
}

.active {
  background-color: #4CAF50;
}
</style>