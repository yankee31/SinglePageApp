<template>
	<div class="services">
		<h1>this isservices</h1>
	</div>
</template>
<script>
export default{
	name: 'services',	
};	
</script>
<style>
</style>
