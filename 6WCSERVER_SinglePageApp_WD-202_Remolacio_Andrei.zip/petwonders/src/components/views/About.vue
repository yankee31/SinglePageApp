<template>
	<div class="about">
		<h1>this is about</h1>
	</div>
</template>
<script>
export default{
	name: 'about',	
};	
</script>
<style>
</style>
