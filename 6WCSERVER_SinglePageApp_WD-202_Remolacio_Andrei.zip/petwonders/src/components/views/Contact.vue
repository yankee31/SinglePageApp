<template>
	<div class="contact">
		<h1>this is conatct/h1>
	</div>
</template>
<script>
export default{
	name: 'contact',	
};	
</script>
<style>
</style>
