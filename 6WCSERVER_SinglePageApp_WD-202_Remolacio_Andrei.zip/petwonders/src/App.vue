<template>
  <div id="app">
    <div id="nav">
      
      <span id="logo">PW</span>
      <router-link to="/">Home</router-link> 
      <router-link to="/about">About</router-link> 
      <router-link to="/services">Services</router-link> 
      <router-link to="/contact">Contact</router-link> 
    </div>
    <router-view/>
    <Footer />
  </div>
</template>
<script>
  import Footer from './components/layout/Footer'
export default {
  name: 'app',
  components: {
    Footer
  }
};
</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Monda:wght@700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  
  color: #2c3e50;
}
body{
  background-color: #F4CB5E
}
#logo{
    padding: 12px 16px 12px;
    color:white;
    border-radius: 50%;
    border-style: solid;
    border-width: 5px;
  font-size: 32px;
  font-family: 'Bebas Neue', cursive;
  }
#nav {
  padding: 30px;
  position: fixed;
  background-color: #F4CB5E;
  width: 100%;
  top:0;
  left:0;
}

#nav a {
  font-family: 'Monda', sans-serif;
  padding-left: 4%;
  font-weight: bold;
  font-size: 28px;
  color: #50A19C;
  text-decoration: none;
}
#nav a:hover{
  color: white;
}
#nav a.router-link-exact-active {
  color: white;
}
</style>
