<template>
<div class="home">
<center>
<table>
	<tr>
	<td>
	<div class="container img-hover-zoom img-hover-zoom--blur">
		<img class="img"  src="../assets/img/Birds.png">
		<div class="middle">
		<div class="text"><a href="#">Birds for sale</a>
		</div>
		</div>
	</div>
	</td>
	<td>
	<div class="container img-hover-zoom img-hover-zoom--blur">
		<img class="img" src="../assets/img/Dogs.jpg">
		<div class="middle">
		<div class="text"><a href="#">Dogs for sale</a>
		</div>
		</div>
	</div>
	</td>
	</tr>
	<tr>
	<td>
	<div class="container img-hover-zoom img-hover-zoom--blur">
		<img class="img"  src="../assets/img/Small Animals.jpg">
		<div class="middle">
		<div class="text"><a href="#">Rabbit for sale</a>
		</div>
		</div>
	</div>
	</td>
	<td>
	<div class="container img-hover-zoom img-hover-zoom--blur">
		<img class="img"  src="../assets/img/Cats.jpg">
		<div class="middle">
		<div class="text"><a href="#">Cats for sale</a>
		</div>
		</div>
	</div>
	</td>
	</tr>
</table>
</center><br><br><br>
</div>
</template>

<script>

</script>
<style>
.home{
	margin-top: 164px;

}
a{
	text-decoration: none;
	color:white;
}
.img{
	object-fit: cover;
	width: 500px;
	height: 350px;

  overflow: auto;
}
.img-hover-zoom {
  overflow: hidden; 
}
.img-hover-zoom--blur img {
  transition: transform 1s, filter 2s ease-in-out;
  filter: blur(0);
  transform: scale(1);
}

/* The Transformation */
.img-hover-zoom--blur:hover img {
  transform: scale(1.1);
}
.container {
  position: relative;
  width: 500px;
}
.middle {
  transition: .5s ease;
  opacity: 1;
  position: absolute;
  top: 80%;
  left: 45%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}
.text {
	font-family: 'Monda', sans-serif;
  background-color: #50A19C;
  color: white;
  font-size: 28px;
  padding: 16px 32px;
}
.container:hover .middle {
  opacity: 1;
}
</style>