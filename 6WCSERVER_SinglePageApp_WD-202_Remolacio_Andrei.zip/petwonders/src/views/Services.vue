<template>
	<div class="services">
		<h1>this isservices</h1>
		<center>
		<table>
			<tr>
				<td><div class="container img-hover-zoom img-hover-zoom--blur"><img class="image cover" src="../assets/img/Grooming.jpg" alt="Grooming" style="width:300px;height:400px;float:left;">
					<div class="middle">
						<div class="text">Pet Grooming</div>
					</div></div>
					
				</td>
				<td><div class="container img-hover-zoom img-hover-zoom--blur"><img class="cover" src="../assets/img/products.jpg" alt="Products" style="width:300px;height:400px;float:left;">
					<div class="middle">
						<div class="text">Pet Products</div>
					</div></div>
				</td>
			
				<td><div class="container img-hover-zoom img-hover-zoom--blur"><img class="cover" src="../assets/img/Pets.jpg" alt="Pets" style="width:300px;height:400px;float:left;">
					<div class="middle">
						<div class="text">Pets for sale</div>
					</div></div>
				</td>
				<td><div class="container img-hover-zoom img-hover-zoom--blur"><img class="cover" src="../assets/img/Accessories.jpg" alt="Pets" style="width:300px;height:400px;float:left;">
					<div class="middle">
						<div class="text">Pet Accessories</div>
					</div></div>
				</td>
			</tr>
		</table>
		</center>
	</div>
</template>
<script>
export default{
	name: 'services',	
};	
</script>
<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Monda:wght@700&display=swap')
* {
  box-sizing: border-box;
}
table{
	margin-top: 48px;

}
.cover{
	object-fit: cover;
}

.column {
padding-top:56px;
  float: left;
  width: 45%;
  font-size: 36px;
  text-align: center;
  font-family: 'Lato', sans-serif;
}
.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
.img-hover-zoom {
  height: 800px; 
  overflow: hidden; 
}
.img-hover-zoom--blur img {
  transition: transform 1s, filter 2s ease-in-out;
  filter: blur(0);
  transform: scale(1);
}
.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 25%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}
.text {
	font-family: 'Monda', sans-serif;
  background-color: #50A19C;
  color: white;
  font-size: 32px;
  padding: 16px 32px;
}
/* The Transformation */
.img-hover-zoom--blur:hover img {
  filter: blur(1px);
  transform: scale(1.1);
}
.container {
  position: relative;
  width: 300px;
}
.container:hover .middle {
  opacity: 1;
}

@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
