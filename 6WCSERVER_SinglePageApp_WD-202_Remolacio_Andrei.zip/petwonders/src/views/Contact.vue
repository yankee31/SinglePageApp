<template>
	<div class="contact">
		<div class="soft">
			<div class="container">
			<h2>Get in touch</h2>
			<form action="#">
				<input  type="text" name="Name" placeholder="Your Name" required>
				<input type="email" name="Email Address" placeholder="Email Address" required>
				<textarea placeholder="Type your message here"></textarea>
				<button type="submit">Send</button>
			</form>
			<p><font-awesome-icon icon="phone" /> SMART: 0908 785 7198</p>
			<p><font-awesome-icon icon="phone" /> GLOBE: 0995 046 3659</p>
			<p><font-awesome-icon icon="map-marker-alt" /> Blk. 19, Lot 10. Calle 3, Xevera Subd. Brgy. Calibutbut, Bacolor Pampanga
			</p>
			</div>
	</div></div>
</template>
<script>
export default{
	name: 'contact',	
};	
</script>
<style scoped>
p{
	font-size:16px;
  text-align: center;
}
.soft{
	margin-top: 164px;
	margin-bottom: 72px;
	margin-left: 28%;
	padding-left: 48px;
	padding-top: 24px;
height: 500px;
width: 500px;
border-radius: 28px;
background: #F4CB5E;
box-shadow:  10px 10px 30px #cfad50, 
             -10px -10px 30px #ffe96c;
}
.container {
  max-width: 400px;
  width: 100%;
  position: relative;
}
input {
  outline: 0;
  border-width: 0 0 2px;
  border-color: #cfad50;
  background:none;
}
input:focus {
  border-color: white;
}
#contact input[type="text"],
#contact input[type="email"],
#contact textarea,
#contact button[type="submit"] {
  font: 400 12px/16px "Roboto", Helvetica, Arial, sans-serif;
}

input[type="text"],
 input[type="email"],
 textarea {
  width: 100%;
  margin: 0 0 5px;
  padding: 10px;
  background:none;

}

textarea {
  height: 100px;
  max-width: 100%;
  resize: none;
}

button[type="submit"] {
  cursor: pointer;
  width: 425px;
  border: none;
  background: #50A19C;
  color: #FFF;
  margin: 0 0 5px;
  padding: 15px;
  font-size: 15px;
}

 button[type="submit"]:hover {
  background: #78A19E;
  -webkit-transition: background 0.3s ease-in-out;
  -moz-transition: background 0.3s ease-in-out;
  transition: background-color 0.3s ease-in-out;
}

button[type="submit"]:active {
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.5);
}

@media screen and (max-width: 600px) {
  
.container {
  max-width: 100px;
  width: 100%;
  position: relative;
}
.soft{

	margin-left: 25%;
width: 200px;
}
button[type="submit"] {
  cursor: pointer;
  width: 128px;
  }
}

</style>
