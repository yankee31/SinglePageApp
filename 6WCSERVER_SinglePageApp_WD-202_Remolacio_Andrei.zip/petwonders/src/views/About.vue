<template>
	<div class="about">
		<h2>ABOUT US</h2>
		<div class="col1">
			Pet Wonders owned by<h3>Andrei Remolacio. </h3>
			This petshop Imports/Exports pets of various breeds from inside or outside the country. <br><br>
			We volunteer for Animal rescues and re-homing for the Strays.
		</div>
		<div class="col2">
			<img src="../assets/img/aboutpic1.jpg">
			<img src="../assets/img/aboutpic2.jpg">
		</div>
	</div>
</template>
<script>
export default{
	name: 'about',	
};	
</script>
<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Lato&display=swap');
h2{
	text-align: center;
	position:fixed;
	padding-top: 32px;
	margin-left: 4%;
	width: 128px;
	color:white;
	border-bottom: 5px solid white;
}
.about{
	padding-top: 72px;
}
img{
	width: 64%;
}
.col1 {
padding-top:104px;
  position:fixed;
  float: left;
  width: 48%;
  padding-left: 4%;
  font-size: 32px;
  text-align: center;
  font-family: 'Lato', sans-serif;
}
.col2 {

padding-top:32px;
  padding-left: 12%;
  float: left;
  margin-left: 50%;
  width: 52%;
  overflow: auto;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
@media screen and (max-width: 600px) {
  
.col1, .col2 {
    width: 100%;
  }
}
</style>
